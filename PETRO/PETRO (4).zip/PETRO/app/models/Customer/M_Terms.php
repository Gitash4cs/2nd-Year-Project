<?php 
    class M_Terms extends Model{
  

        public function terms($data){
            $result=$this->connection();

     
        
        }
    }
?>