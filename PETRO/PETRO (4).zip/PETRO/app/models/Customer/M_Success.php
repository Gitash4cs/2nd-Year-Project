<?php
    

class M_Success extends Model
{

}