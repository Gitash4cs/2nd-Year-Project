<?php 
class M_Updatemachine extends Model
{
    protected $table = 'user_form';
    protected $table3 = 'machines';
    protected $table4 = 'registered_users';


    public function updatemachine($data){
    

        $id = $_SESSION['CUS_id'];
        $result=$this->connection();
        $sql = "select * from $this->table  where id='".$id."'";
        $query=$result->query($sql);
        while($row = $query->fetch_array()){
    
            $sNo= $row['sNo'];
       

            $vno1= $row['vno1'];
         
            $vno= $row['vno'];
           
            $vno2= $row['vno2'];
           
            $email = $row['email'];
            
          
        }


        
        $sql0 = "select * from $this->table4  where email='".$email."'";
        $query0=$result->query($sql0);
        while($row = $query0->fetch_array()){
    
         
            $phone= $row['phone'];
           
         
            
          
        }


        $sql2 = "select * from $this->table3  where phone='".$phone."' AND mno='".$sNo."'";
        $query2=$result->query($sql2);
        while($row = $query2->fetch_array()){
    
            $mno= $row['mno'];
            $mtype = $row['mtype'];
            $ftype = $row['ftype'];
      
            
          
        }

        $arr=array(
            'sNo' => $mno,
            'type'=>$mtype,
            'ftype3'=>$ftype,

            'vno1' => $vno1,
           
          
            'vno2' => $vno2,
         

            'vno' => $vno,
           

            'phone'=>$phone,
           
          
        );
        return $arr;
    }

    public function add($data){
        $result=$this->connection();
        $id = $_SESSION['CUS_id'];
    
        $sNo = $data['sNo'];
        $type = $data['type'];
        $ftype3 = $data['ftype3'];
        $phone = $data['phone'];
   

        $sql1= "UPDATE $this->table SET sNo=NULL WHERE id='".$id."'";
        $query1 = $result->query($sql1);
        



        $sql4= "UPDATE $this->table3 SET status=0 WHERE phone='".$phone."' AND mno='".$sNo."'";
        $query4 = $result->query($sql4);

     


        if(($query1 && $query4)){

            return true;
        }
        else{
            echo "vvvvvvvvv";
        }
    }
   }
