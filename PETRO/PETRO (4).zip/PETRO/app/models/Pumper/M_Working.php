<?php

class M_Working extends Model
{
    protected $table = 'complete_order';
    public function details_working($data){
        $pumper_id = $_SESSION['id'];
        $result = $this->connection();
        $count=0;
        $total=0;

        $sql="select count(distinct order_id)AS COUNT,count(order_id)AS total from $this->table where pumper_id = '".$pumper_id."'ORDER BY ID DESC ";
        $query = $result->query($sql);

        if($query->num_rows>0){

            while($row=$query->fetch_array())
            {
                $count=$row['COUNT'];
                $total=$row['total'];
            
            }
        }
     

      

        $sql="select *from $this->table where pumper_id = '".$pumper_id."'ORDER BY ID DESC ";
        $query = $result->query($sql);

       
        if($query->num_rows>0){

    
            $data=[
                'result'=>$query,
                'COUNT'=>$count,
                'total'=>$total,
                'date'=>'Today',
                'ID'=>$pumper_id,
                
                'error'=>'',
            ];
            return $data;
    }
    else{
        $data=[
            'COUNT'=>$count,
            'total'=>$total,
            'date'=>'Today',
            'ID'=>$pumper_id,
            
            'error'=>'No Records',
        ];
        return $data;
    }
    
    }
    public function previous1($data){
        $from = $data['from'];
        $to =$data['to'];
        $pumper_id = $_SESSION['id'];
        $date = $from.'-'.$to;
        $result = $this->connection();
        $count=0;
        $total=0;

        $sql="select count(distinct order_id)AS COUNT,count(order_id)AS total from $this->table where pumper_id = '".$pumper_id."'AND(DATE(time)>='".$from."' AND DATE(time)<'".$to."')";
        $query = $result->query($sql);

        if($query->num_rows>0){

            while($row=$query->fetch_array())
            {
                $count=$row['COUNT'];
                $total=$row['total'];
            
            }
        }

        $sql="select *from $this->table where (pumper_id = '".$pumper_id."') AND(DATE(time)>='".$from."' AND DATE(time)<='".$to."')";
        $query = $result->query($sql);
        if($query->num_rows>0){
            $data=[
                'ID'=>$pumper_id,
                'result'=>$query,
                'COUNT'=>$count,
                'total'=>$total,
                'date'=>$date,
                'error'=>'',
            ];
            return $data;
        }
        else{
            $data=[
                'ID'=>$pumper_id,
                'COUNT'=>$count,
                'total'=>$total,
                'date'=>$date,
                'error'=>'No Records..!!',
            ];
            return $data;
        }

    }
}