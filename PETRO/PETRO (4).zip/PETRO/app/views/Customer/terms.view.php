
















<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Background Change Automatic - Sagar Developer</title>
    <link rel="stylesheet" href="<?php echo ROOT?>/CSS/Customer/terms.css" text="text/css">

</head>

<body>
    <div class="Section_top">
        <header>
            <a href="#"><img src="<?php echo ROOT ?>/image/Common/log.png" alt="" class="image"></a>
        </header>
        <div class="wrapper">
          


                  
        <ul>
  <li>When you place a fuel order you should complete that within 3 days.Otherwise Order will cancel.</li>
  <li>You cannot place more than 5 fuel orders</li>
  <li>There is a Maximum amount of liters that you can order at once according to your vehicle type</li>
  <li>You will get a relevant number of points after you complete your order. You can redeem that points after it exceeds more than 100.</li>
  <li>If the petro points exceeds 300 it will sutomatically reduced from your bill</li>
  <li>You will get 5 petro points per any type of fuel liter and 5 Petro points for any type of Lubricant</li>
  <li>We only do delivery from our Store. You cannot come and collect the product from the filling station</li>


</ul>  




        </div>
    </div>


    





 
 






</body>
</html>










