<?php

class M_Delete_cus extends Model{
    protected $table='user_form';
    public function records($data){
        $id = $_SESSION['id'];
        
        
        $result = $this->connection();

            $sql="delete *from $this->table  where id=6";
            $query=$result->query($sql);
            return true;
        }
      
    }
