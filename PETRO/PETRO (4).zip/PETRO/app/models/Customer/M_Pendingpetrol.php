<?php

class M_Pendingpetrol extends Model
{
    protected $table = 'ordert';
    public function pendingpetrol($data){
        $id = $_SESSION['id'];
        $result = $this->connection();
        $sql="select *from $this->table where id = '".$id."'";
        $query = $result->query($sql);
        
        if($query->num_rows>0){
                $data=[
                    'result'=>$query,
                    'error'=>'',
                ];
                return $data;
        }
        else{
            return false;
        }
    }

    public function add($data){
        $result1=$this->connection();
        $delete =$data ['delete'];
   

        $sql = "DELETE from $this->table WHERE Oid='".$delete."'";
         $query3 = $result1->query($sql); 

         

         if($query3){
         
                return 1;       
        
        }
       else{
        return 6;
     }
    
      }
}