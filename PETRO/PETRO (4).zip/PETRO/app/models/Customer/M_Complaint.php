<?php

class M_Complaint extends Model
{
    protected $table = 'user_form';
    protected $table2='complain';

    
    public function complaint($data){
    

        $id = $data['id'];
        $result=$this->connection();
        $sql = "select * from $this->table where id='".$id."'";
        $query=$result->query($sql);
        while($row = $query->fetch_array()){
            $id= $row['id'];
            $email = $row['email'];
       
           
          
        }

        $sql6="select *from $this->table2  where user_id = '".$id."'" ;
        $query6 = $result->query($sql6);

        $arr=array(
            'id' => $id,
            'email'=>$email,
           
            'result'=>$query6,
          
          
        );
        return $arr;
    }
              
            


    public function add($data){
        $result1=$this->connection();
        $id =$data ['id'];
      

        $complaint =$data ['complaint'];
      
  

         $sql = "INSERT INTO $this->table2 (customer_id,complain) VALUES('$id','$complaint')";
         $query3 = $result1->query($sql); 

         $sql = "select * from $this->table where id='".$id."'";
         $query=$result1->query($sql);
         while($row = $query->fetch_array()){
             $id= $row['id'];
             $email = $row['email'];
             $fname = $row['fname'];
            
           
         }
 
         $sql6="select *from $this->table2  where customer_id = '".$id."'" ;
         $query6 = $result1->query($sql6);

         $error="Successful";
    
         $data=[
            'id' => $id,
            'email'=>$email,
            'fname'=>$fname,
            'result'=>$query6,
             'error'=>$error,
            
         ];
         return $data;

        }
           }
          
          
    






