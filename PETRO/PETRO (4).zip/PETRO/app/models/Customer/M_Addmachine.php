<?php 
class M_Addmachine extends Model
{
    protected $table = 'user_form';
    protected $table2 = 'machines';
    protected $table3 = 'registered_users';


    public function addmachine($data){
    

        $id = $data['id'];
        $result=$this->connection();
        $sql = "select * from $this->table  where id='".$id."'";
        $query=$result->query($sql);
        while($row = $query->fetch_array()){
    
            $vno= $row['vno'];
         

            $vno1= $row['vno1'];
           

            $sNo= $row['sNo'];
           

            $vno2= $row['vno2'];
          

            $email = $row['email'];
            
          
        }



        $sql2 = "select * from $this->table3  where email='".$email."'";
        $query2=$result->query($sql2);
        while($row = $query2->fetch_array()){
    
         
         

            $phone = $row['phone'];
            
          
        }


        $arr=array(
            'vno' => $vno,
          
            'vno1' => $vno1,
           
          
            'vno2' => $vno2,
           
            'sNo' => $sNo,
      

            'phone'=>$phone,
          
        );
        return $arr;
    }

    public function add($data){
        $result=$this->connection();
        $id = $_SESSION['CUS_id'];
    
        $sNo = $data['sNo'];
        $type = $data['type'];
        $ftype3 = $data['ftype3'];
        $phone = $data['phone'];
   


        $select2 =  "SELECT * FROM $this->table  WHERE sNo = '".$sNo."'";
        $query4 = $result->query($select2);



        
        if($query4->num_rows>0){

            
            $error="Machine Already Exists";

            $sql = "select * from $this->table  where id='".$id."'";
            $query=$result->query($sql);
            while($row = $query->fetch_array()){
        
                $vno= $row['vno'];
          
    
                $vno1= $row['vno1'];
             
    
                $sNo= $row['sNo'];
             
    
                $vno2= $row['vno2'];
       

                $email= $row['email'];
                
              
            }


            $sql2 = "select * from $this->table3  where email='".$email."'";
            $query2=$result->query($sql2);
            while($row = $query2->fetch_array()){
        
             
             
    
                $phone = $row['phone'];
                
              
            }
       
               $data=[
                   'vno' => $vno,
                   'vno1' => $vno1,
                   'vno2' => $vno2,
                   'sNo' => $sNo,
                   'error'=>$error,
                   'phone'=>$phone,
                 
                   
       
           
   
                  
               ];
               return $data;
             }

        else{

            
        $sql1= "UPDATE $this->table SET sNo='$sNo' WHERE id='".$id."'";
        $query1 = $result->query($sql1);
  

        $sql4= "INSERT INTO $this->table2 (phone,mno,mtype,ftype) VALUES('$phone','$sNo','$type','$ftype3')";
        $query4 = $result->query($sql4);

            return 1;
        }

          
      
    }
   }
