<?php

class M_Register extends Model
{
    protected $table='user_form';

   protected $table1 = 'registered_users';
   protected $table2 = 'vehicles';
   protected $table3 = 'machines';

    public function register($data){

        $fname = $data ['fname'];
        $lname = $data ['lname'];
     
        $email =$data['email'];
        
        $NIC =$data['NIC'];
        $phone =$data ['phone'];
        $vno =$data ['vno'];
        $vtype =$data ['vtype'];
        $ftype =$data ['ftype'];
        
        $sNo =$data ['sNo'];
        $type =$data ['type'];
        $ftype2 =$data ['ftype2'];
        
        $pass =$data ['pass'];
        $cpass =$data ['cpass'];


     $result = $this->connection();
    $select =  "SELECT * FROM $this->table WHERE email = '".$email."' OR phone='".$phone."'";
    $query1 = $result->query($select);
    
    $select2 =  "SELECT * FROM $this->table  WHERE vno = '".$vno."' OR vno1='".$vno."' OR vno2='".$vno."'";
    $query2 = $result->query($select2);
    

    if($query1->num_rows>0){
        return 2;

   }
   if($query2->num_rows>0){
    
      return 3;
    }
    
      if($pass != $cpass){
        return 4;
      }

      else{
         $password=password_hash($pass,PASSWORD_BCRYPT);
         $insert = "INSERT INTO $this->table (email,vno,sNo,points) VALUES( '$email','$vno','$sNo','$points')";
         $query3 = $result->query($insert); 
         $sql = "INSERT INTO $this->table1 (email,password,fname,lname,NIC,phone,role,status)values('$email','$password','$fname','$lname','$NIC','$phone','customer',1)";
         $connect = $result->query($sql);
         $sql4= "INSERT INTO $this->table2 (phone,vno,vtype,ftype) VALUES('$phone','$vno','$vtype','$ftype')";
         $query4 = $result->query($sql4);

         $sql3 = "INSERT INTO $this->table3 (phone,mno,mtype,ftype)values('$phone','$sNo','$type','$ftype2')";
         $connect3 = $result->query($sql3);
     
      
           
            return 1;
        
         
      }
   }










     
     

       }     
