<?php
define('ROOT','http://localhost/PETRO/public');