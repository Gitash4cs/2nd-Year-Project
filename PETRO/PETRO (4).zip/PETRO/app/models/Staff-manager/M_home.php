<?php

class M_profile extends Model{
   

    public function staff_details($data){
        
        


    }

}