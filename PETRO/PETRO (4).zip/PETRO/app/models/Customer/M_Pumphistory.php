<?php

class M_Pumphistory extends Model
{
    protected $table = 'ordert';
    protected $table2 = 'complete_order';
    public function pumphistory($data){
        $id = $_SESSION['CUS_id'];
        $result = $this->connection();
        $sql="select *from $this->table2 where user_id = '".$id."' ORDER BY order_id DESC";


        
        $query = $result->query($sql);

      
        
        if($query->num_rows>0){
                $data=[
                    'result'=>$query,
                    'error'=>'',
                ];
                return $data;
        }
        else{
            return false;
        }
    }


    public function add($data){
        $result=$this->connection();
        $id = $_SESSION['id'];
        $startDate = $data['startDate'];
        $finishDate = $data['finishDate'];
 
        $sql12="SELECT *FROM $this->table2 WHERE (DATE(time)>='".$startDate."' AND DATE(time)<='".$finishDate."') AND user_id='".$id."'";
        $query12=$result->query($sql12);
     
      
        if($query12->num_rows>0){
          
            while($row=$query12->fetch_array()){
                $data=[
                    'result'=>$query12,
                    'error'=>'',
                ];
                return $data;
        }}
        else{
            return false;
        }
            
        }


        

           }


       
      

