<?php
    

class M_Fail extends Model
{

}