<?php

class _404 extends Controller
{
    public function index(){
        echo "Page Not Found!";
    }
}