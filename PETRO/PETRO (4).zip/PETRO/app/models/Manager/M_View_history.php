<?php
    class M_View_history extends Model{
        protected $table = 'fuel_stock';

        public function View_history($data){
           // $id = $_SESSION['id'];
            $result = $this->connection();

            $start = 0;
            $rows_per_page = 10;
            $sql="select *from $this->table  ORDER BY `date_field` DESC LIMIT $start,$rows_per_page";
            $query = $result->query($sql);

            $sql2 = "SELECT * FROM $this->table";
            $query2 = $result-> query($sql2);

            $no_rows = $query2->num_rows;
            $pages = ceil($no_rows/$rows_per_page);

           
                if($query->num_rows>0){
                
                    $data=[
                        'result'=>$query,
                        'page' => $pages,
                        'error'=>'',
                    ];
                    return $data;
            }
            else{
                return false;
            
            }
            

    }

        public function get_Date($data){
            $result = $this->connection();
            $startDate =$data['startDate'];
            $finishDate =$data['finishDate'];

            echo $startDate;
        }
}
?>
